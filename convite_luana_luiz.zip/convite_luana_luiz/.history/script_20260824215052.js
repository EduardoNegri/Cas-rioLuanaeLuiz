const target = new Date("2026-12-27T16:00:00-03:00");

// Cole aqui o link do seu Google Forms:
const GOOGLE_FORMS_URL = "https://docs.google.com/forms/d/e/1FAIpQLSeqCq_AbeaCCi61BylGzaQmTGtP6ZFomykgazOcW2sYDdunLw/viewform?usp=publish-editor";

function updateCountdown() {
  const now = new Date();
  let diff = target - now;

  if (diff < 0) diff = 0;

  const days = Math.floor(diff / 86400000);
  const hours = Math.floor((diff / 3600000) % 24);
  const minutes = Math.floor((diff / 60000) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  document.getElementById("days").textContent = String(days).padStart(2, "0");
  document.getElementById("hours").textContent = String(hours).padStart(2, "0");
  document.getElementById("minutes").textContent = String(minutes).padStart(2, "0");
  document.getElementById("seconds").textContent = String(seconds).padStart(2, "0");
}

updateCountdown();
setInterval(updateCountdown, 1000);

document.getElementById("openRsvp").addEventListener("click", () => {
  if (
    !GOOGLE_FORMS_URL ||
    GOOGLE_FORMS_URL === "COLE_SEU_LINK_DO_GOOGLE_FORMS_AQUI"
  ) {
    alert("Adicione o link do Google Forms no arquivo script.js.");
    return;
  }

  window.location.href = GOOGLE_FORMS_URL;
});
