CONVITE LUANA & LUIZ EDUARDO — V10 MOBILE 100% LIMPO

Esta versão foi feita para celular com:
- apenas faixa floral superior;
- apenas faixa floral inferior;
- sem flores laterais;
- sem cantos florais;
- layout mais limpo e centralizado para leitura.

Desktop e tablet continuam com a estrutura normal.
